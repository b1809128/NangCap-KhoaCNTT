<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Content.joomla
 * @copyright	@copyright	Copyright (c) 2019 svtemp. All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

defined('_JEXEC') or die;

class PlgSystemGoTop extends JPlugin
{

	public function onAfterDispatch()
	{

JHtml::_('behavior.framework', true);

$app	= JFactory::getApplication();
$menu   = $app->getMenu();
$doc = JFactory::getDocument();

$siteUrl = JUri::root();

// Get plugin 'my_plugin' of plugin type 'my_plugin_type'
$plugin = JPluginHelper::getPlugin('system', 'gotop');

// Check if plugin is enabled
if ($plugin)
{
// Get plugin params
$pluginParams = new JRegistry($plugin->params);

$pluginoptiondown = $pluginParams->get('pluginoptiondown');
$scrollbottomtitle = $pluginParams->get('scrollbottomtitle');
$bottomimage = $pluginParams->get('bottomimage', 'plugins/system/gotop/img/scrollTobottom.png');

$topimage = $pluginParams->get('topimage', 'plugins/system/gotop/img/scrollToTop.png');
$topimagehover = $pluginParams->get('topimagehover');
$plugindisplay = $pluginParams->get('plugindisplay');
$iconbackgroundcolor = $pluginParams->get('iconbackgroundcolor');
$iconhoverbackgroundcolor = $pluginParams->get('iconhoverbackgroundcolor', 'transparent');
$scrolltoptitle = $pluginParams->get('scrolltoptitle');
$topoffset = $pluginParams->get('topoffset');

$icontopheight = $pluginParams->get('icontopheight');
$icontopwidth = $pluginParams->get('icontopwidth');
$iconborderradius = $pluginParams->get('iconborderradius');
$iconposition = $pluginParams->get('iconposition');
$iconmarginbottom = $pluginParams->get('iconmarginbottom');

$iconmarginleft = $pluginParams->get('iconmarginleft');
$iconmarginright = $pluginParams->get('iconmarginright');

$responsivescrolltop = $pluginParams->get('responsivescrolltop');
$plugincss = $pluginParams->get('plugincss');
}

$style = '
.boxnavbuttons {width:'.$icontopwidth.'; bottom: '.$iconmarginbottom.'; position:fixed; z-index: 10001; display: none;}

.backtotop{ transition: background 0.35s ease; margin-bottom: 2px; background-size: 100% 100% !important; background-image: url("'.$siteUrl.''.$topimage.'"); background-color: '.$iconbackgroundcolor.'; width:'.$icontopwidth.'; height:'.$icontopheight.'; border-radius: '.$iconborderradius.'; z-index: 10001; display: block;}
.backtotop:hover{ background-color: '.$iconhoverbackgroundcolor.'; cursor: pointer; }

.gotobottom{ transition: background 0.35s ease; margin-bottom: 2px; background-size: 100% 100% !important; background-image: url("'.$siteUrl.''.$bottomimage.'"); background-color: '.$iconbackgroundcolor.'; width:'.$icontopwidth.'; height:'.$icontopheight.'; border-radius: '.$iconborderradius.'; z-index: 10001; display:block;}
.gotobottom:hover { background-color: '.$iconhoverbackgroundcolor.'; cursor: pointer; }

@media only screen and (max-width: '.$responsivescrolltop.') {
.gototop {display: none !important;}
}
'; 
$doc->addStyleDeclaration( $style );


if ( $iconposition == 'right')
{
$style = '
.boxnavbuttons{right: '.$iconmarginright.';}
'; 
$doc->addStyleDeclaration( $style );
}
	
if ( $iconposition == 'left')
{
$style = '
.boxnavbuttons{left: '.$iconmarginleft.';}
'; 
$doc->addStyleDeclaration( $style );
}

if ( $iconposition == 'center')
{
$style = '
.boxnavbuttons{left: calc(50% - '.$icontopwidth.'/2);}
'; 
$doc->addStyleDeclaration( $style );
}

if ($pluginParams->get('jquerygototop')) {$doc->addScript ('https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js');}
$doc = JFactory::getDocument();
	

if( $plugindisplay == 1 ) {
if ( JFactory::getApplication()->isAdmin() )
		{
			return true;
		}		
}
		
if( $plugindisplay == 2 ) {
if ( JFactory::getApplication()->isSite() )
		{
			return true;
		}		
}

if( $plugindisplay == 3 ) {
if ( JFactory::getApplication()->isSite() && JFactory::getApplication()->isAdmin()  )
		{
			return true;
		}		
}
	
	$js = "
jQuery(document).ready(function() {
	
var scrollDiv = document.createElement('div');
jQuery(scrollDiv).attr('class', 'boxnavbuttons').html('').appendTo('body');
	  });	

    jQuery(window).scroll(function(){
        if (jQuery(this).scrollTop() > " .$topoffset. ") {
            jQuery('.boxnavbuttons').fadeIn();
	    } else {
            jQuery('.boxnavbuttons').fadeOut();
        }
    });

jQuery(document).ready(function() {
var scrollDiv = document.createElement('div');
jQuery(scrollDiv).attr('class', 'backtotop').attr('title', '".$scrolltoptitle."').html('').appendTo('.boxnavbuttons');
	  });	
	
jQuery(document).ready(function(){

    //Click event to scroll to top
    jQuery('.backtotop').click(function(){
        jQuery('html, body').animate({scrollTop : 0},800);
        return false;
    });

});
";
$doc->addScriptDeclaration($js);

// Button - go to Bottom
if( $pluginoptiondown == 1 ) {
	$js = "
	// Create button
jQuery(document).ready(function() {
var scrollDiv = document.createElement('div');
jQuery(scrollDiv).attr('class', 'gotobottom').attr('title', '".$scrollbottomtitle."').html('').appendTo('.boxnavbuttons');
	  });	

jQuery(document).ready(function(){

    //Click event to scroll to bottom
jQuery('.gotobottom').click(function(){
        jQuery('html, body').animate({scrollTop:jQuery(document).height()}, 800);
        return false;
    });

 });

";
$doc->addScriptDeclaration($js);
}

// plugin css
$style = '
' .$plugincss. '
'; 
$doc->addStyleDeclaration( $style );

return true;

	}
}